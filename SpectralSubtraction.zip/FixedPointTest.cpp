// FIXED POINT TEST CODE

#include<stdio.h>
void main() {

	// Floating point arithmetic.
	float f1 = 14.11f;
	float f2 = 56.78f;
	printf("%f * %f = %f\n", f1, f2, f1 * f2);
	printf("%f / %f = %f\n", f1, f2, f1 / f2);
	printf("%f + %f = %f\n", f1, f2, f1 + f2);
	printf("%f - %f = %f\n", f1, f2, f1 - f2);

	// Fixed point arithmetic.
	//int M = 10;
	int N = 6;
	int x1 = (int)(f1 * (1 << N));    // Q23.6
	int x2 = (int)(f2 * (1 << N));    // Q23.6
	int iTemp = 0;

	// 1. Multiplication
	int x1x2 = (x1 * x2) >> N;
	printf("%d * %d = %d, in float: %f\n", x1, x2, x1x2, (float)x1x2 / (1 << N));
	//iTemp = x1x2 >= 0 ? ((float)x1x2 / (1 << N) + 0.5) : ((float)x1x2 / (1 << N) - 0.5);
	//printf("For Round Caculation Multipl result  %d \n", iTemp); // for round
	printf("%d * %d = %d, in float: %d\n", x1, x2, x1x2, x1x2 >> N);

	// 2. Division
	int x1_x2 = (x1 << N) / x2;
	printf("%d / %d = %d, in float: %f\n", x1, x2, x1_x2, (float)x1_x2 / (1 << N));
	//iTemp = x1_x2 >= 0 ? ((float)x1_x2 / (1 << N) + 0.5) : ((float)x1_x2 / (1 << N) - 0.5);
	//printf("For Round Caculation Division result  %d \n", iTemp); // for round
	printf("%d / %d = %d, in float: %d\n", x1, x2, x1_x2, x1_x2 >> N);

	// 3. Plus
	int x1px2 = (x1 + x2);
	printf("%d + %d = %d, in float: %f\n", x1, x2, x1px2, (float)x1px2 / (1 << N));
	//iTemp = x1px2 >= 0 ? ((float)x1px2 / (1 << N) + 0.5) : ((float)x1px2 / (1 << N) - 0.5);
	//printf("For Round Caculation plus result %d  \n ", iTemp); // for round
	printf("%d + %d = %d, in float: %d\n", x1, x2, x1px2, x1px2 >> N);

	// 4. Minus
	int x1mx2 = (x1 - x2);
	printf("%d - %d = %d, in float: %f\n", x1, x2, x1mx2, (float)x1mx2 / (1 << N));
	//iTemp = x1mx2 >= 0 ? ((float)x1mx2 / (1 << N) + 0.5) : ((float)x1mx2 / (1 << N) - 0.5);
	//printf("For Round Caculation minus result %d  \n ", iTemp); // for round
	printf("%d - %d = %d, in float: %d\n", x1, x2, x1mx2, x1mx2 >> N);

	return;

}