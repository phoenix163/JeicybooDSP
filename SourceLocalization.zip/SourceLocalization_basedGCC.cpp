/*
Generalized Cross Correlation based Source Localization
This program is made by jongcheol boo.

���� �̸��� �밡���� ǥ�����������.
http://jinsemin119.tistory.com/61 , https://en.wikipedia.org/wiki/Hungarian_notation , http://web.mst.edu/~cpp/common/hungarian.html

We are targetting format of 16kHz SamplingRate, stereo channel, 16bit per sample.

���� �� ��������.

���⿡ ���� �Ǵ��� left, right������ �����ϰ� ������ delay���������� correlation�� �񱳸� ����
���� correlation���� ���� ���� �������� ���Ѵ�.

SamplingRate�� �۰��ϸ�, �׸�ŭ ���⿡ ���� resolution�� ����������.
����Ʈ������ UPLINK, DOWNLINK�� ���� path�� data�� �޾��� ���, �� �� ����ũ�� �Ÿ��� �ⲯ�ؾ� 15cm�̴�.
�׷��⿡, Sample�ϳ��� ������ 10���̻� ���̰� ���� �� �� �ִ�.
�׷���, ������� ���� Ư�� Samplingrate�� �� �� ���� �ʿ䰡 �ִ�.

*/
#include<stdio.h>
#include<string.h>
#include<fftw3.h>
#include<math.h>

#define MAX_QUEUE_SIZE 10
#define FALSE 0
#define TRUE 1
#define PI 3.141592
#define FFT_PROCESSING_LEN 1024
#define BLOCK_LEN 512 // 1000*(512/16000)= 32ms.
#define KEEP_LEN 512
#define CHANNEL 2
#define SAMPLING_RATE 16000.0
//#define SPEED_OF_SOUND 34029 // (cm/sec) ,340.29(m/s)
#define SPEED_OF_SOUND 34000.0 // (cm/sec) ,340.29(m/s)
//#define DISTANCE_OF_MIC 15.79 //
#define DISTANCE_OF_MIC 800.0 //

typedef double element;
typedef struct {
	element queue[MAX_QUEUE_SIZE];
	int rear;
	int front;
} QueueType;

typedef struct {
	double dLeftDelay;
	double dMaxLCorrelation;
	double dLeftAngle;
	double dRightDelay;
	double dMaxRCorrelation;
	double dRightAngle;
}TDOA;

void error(char *message){
	fprintf(stderr, "%s\n", message);
	return;
}
// �ʱ� front�� rear�� 0���� �ϴ� ������
// empty�� full�� �����ϱ� ���� index 0�� ���� ���ؼ���.
void init(QueueType *q){
	q->front = 0;
	q->rear = 0;
}

int is_empty(QueueType *q){
	return q->front == q->rear;
}

// % �����ڴ� ���ѵ� index�� �ݺ��ϱ� ���ؼ� ����Ѵ�
int is_full(QueueType *q){
	return (q->rear + 1) % MAX_QUEUE_SIZE == q->front;
}

void enqueue(QueueType *q, element item){
	if (is_full(q)){
		error("q is full");
		return;
	}
	q->rear = (q->rear + 1) % MAX_QUEUE_SIZE;
	q->queue[q->rear] = item;
}

element dequeue(QueueType *q){
	if (is_empty(q)){
		error("q is empty");
		return -1;
	}
	q->front = (q->front + 1) % MAX_QUEUE_SIZE;
	return q->queue[q->front];
}

element peek(QueueType *q){
	if (is_full(q)) {
		error("q is full");
		return -1;
	}
	return q->queue[(q->front + 1) % MAX_QUEUE_SIZE];
}

double accu_queue(QueueType *q){
	double result = 0;
	int iFront = 0, iRear = 0, iCount = 0;
	iFront = (q->front + 1) % MAX_QUEUE_SIZE;
	iRear = (q->rear + 1) % MAX_QUEUE_SIZE;
	for (int i = iFront; i != iRear; i = ++i%MAX_QUEUE_SIZE) {
		result += q->queue[i];
		iCount++;
	}
	//printf(" iCount %d \n", iCount);
	return result;
}


void EstimationDirectionOfSource(short *rgsInputBufferL, short *rgsInputBufferR, int iFrameCount, TDOA * tdoaResult);

void main(int argc, char** argv) {

	// fRead�� input, fWrite�� processing���� write �� output file pointer.
	TDOA tdoaResult = { 0, };
	FILE *fpRead1, *fpRead2;
	char rgcHeader[44] = { '\0', }; // header�� ������ �迭.
	short rgsInputBufferL[BLOCK_LEN] = { 0, };
	short rgsInputBufferR[BLOCK_LEN] = { 0, };
	if (argc != 3) {
		printf("path�� 2�� �Է��ؾ� �մϴ�.\n"); // input path, output path
		return;
	}
	else {
		for (int i = 1; i < 3; i++)
			printf("%d-th path %s \n", i, argv[i]);
	}

	if ((fpRead1 = fopen(argv[1], "rb")) == NULL)
		printf("Read File Open Error\n");

	if ((fpRead2 = fopen(argv[2], "rb")) == NULL)
		printf("Read File Open Error\n");

	// Read�� Wav ���� �� ���� Header 44Byte ��ŭ Write�� Wav���Ͽ� write.
	fread(rgcHeader, 1, 44, fpRead1);
	fread(rgcHeader, 1, 44, fpRead2);

	while (true)
	{
		if ((fread(rgsInputBufferL, sizeof(short), BLOCK_LEN, fpRead1)) == 0) {
			printf("Break! The buffer is insufficient.\n");
			break;
		}
		if ((fread(rgsInputBufferR, sizeof(short), BLOCK_LEN, fpRead2)) == 0) {
			printf("Break! The buffer is insufficient.\n");
			break;
		}
		EstimationDirectionOfSource(rgsInputBufferL, rgsInputBufferR, BLOCK_LEN, &tdoaResult);
		memset(&tdoaResult, 1, sizeof(tdoaResult));
	}
	printf("Processing End\n");
	fclose(fpRead1);
	fclose(fpRead2);
	getchar();
	return;
}

void EstimationDirectionOfSource(short *rgsInputBufferL, short *rgsInputBufferR, int iFrameCount, TDOA *tdoaResult) {


	fftw_complex fcLeftBefFFT[FFT_PROCESSING_LEN] = { 0, }, fcLeftAftFFT[FFT_PROCESSING_LEN] = { 0, };
	fftw_complex fcRightBefFFT[FFT_PROCESSING_LEN] = { 0, }, fcRightAftFFT[FFT_PROCESSING_LEN] = { 0, };
	fftw_complex fcLeftDelayCorrBefFFT[FFT_PROCESSING_LEN] = { 0, }, fcLeftDelayCorrAftfFFT[FFT_PROCESSING_LEN] = { 0, };
	fftw_complex fcRightDelayCorrBefFFT[FFT_PROCESSING_LEN] = { 0, }, fcRightDelayCorrAftfFFT[FFT_PROCESSING_LEN] = { 0, };
	fftw_plan fpLeft_p, fpRight_p, fpLDelay_p, fpRDelay_p;
	static fftw_complex fcLKeepBuf[KEEP_LEN] = { 0, };
	static fftw_complex fcRKeepBuf[KEEP_LEN] = { 0, };
	static QueueType maxCorrL = { 0, };
	static QueueType maxCorrR = { 0, };
	double dTemp = 0.0;
	double dAccuMaxCorrL = 0.0 , dAccuMaxCorrR = 0.0;
#if 0
	tdoaResult->dLeftAngle = 0;
	tdoaResult->dLeftDelay = 0;
	tdoaResult->dMaxLCorrelation = 0;
	tdoaResult->dMaxRCorrelation = 0;
	tdoaResult->dRightAngle = 0;
	tdoaResult->dRightDelay = 0;

	for (int i = 0; i < iFrameCount; i++) {
		if ((i % CHANNEL) == 0)
			fcLeftBefFFT[i / CHANNEL][0] = rgsInputBuffer[i];
		else
			fcRightBefFFT[i / CHANNEL][0] = rgsInputBuffer[i];
	}
#endif


	memcpy(fcLeftBefFFT, fcLKeepBuf, sizeof(fftw_complex) * KEEP_LEN);
	memcpy(fcRightBefFFT, fcRKeepBuf, sizeof(fftw_complex) * KEEP_LEN);
	for (int i = 0; i < iFrameCount; i++) {
		fcLeftBefFFT[i + KEEP_LEN][0] = rgsInputBufferL[i];
		fcRightBefFFT[i + KEEP_LEN][0] = rgsInputBufferR[i];
	}

	// Left channel FFT processing
	fpLeft_p = fftw_plan_dft_1d(FFT_PROCESSING_LEN, fcLeftBefFFT, fcLeftAftFFT, FFTW_FORWARD, FFTW_ESTIMATE);
	fftw_execute(fpLeft_p);

	// Right channel FFT processing
	fpRight_p = fftw_plan_dft_1d(FFT_PROCESSING_LEN, fcRightBefFFT, fcRightAftFFT, FFTW_FORWARD, FFTW_ESTIMATE);
	fftw_execute(fpRight_p);


	for (int i = 0; i < FFT_PROCESSING_LEN; i++) {
		fcRightDelayCorrAftfFFT[i][0] = fcLeftAftFFT[i][0] * fcRightAftFFT[i][0] - fcLeftAftFFT[i][1] * fcRightAftFFT[i][1];
		fcRightDelayCorrAftfFFT[i][1] = -fcLeftAftFFT[i][0] * fcRightAftFFT[i][1] + fcLeftAftFFT[i][1] * fcRightAftFFT[i][0];
		dTemp = abs(sqrt(pow(fcRightDelayCorrAftfFFT[i][0], 2.0) + pow(fcRightDelayCorrAftfFFT[i][1], 2.0)));
		fcRightDelayCorrAftfFFT[i][0] /= dTemp;
		fcRightDelayCorrAftfFFT[i][1] /= dTemp;
	}

	// Calculate GCC for Right Direction IFFT processing
	fpRDelay_p = fftw_plan_dft_1d(FFT_PROCESSING_LEN, fcRightDelayCorrAftfFFT, fcRightDelayCorrBefFFT, FFTW_BACKWARD, FFTW_ESTIMATE);
	fftw_execute(fpRDelay_p);

	for (int i = 0; i < FFT_PROCESSING_LEN; i++) {
		fcRightDelayCorrBefFFT[i][0] *= 1. / FFT_PROCESSING_LEN;
	}

	for (int i = 0; i < FFT_PROCESSING_LEN; i++) {
		fcLeftDelayCorrAftfFFT[i][0] = fcRightDelayCorrAftfFFT[i][0];
		fcLeftDelayCorrAftfFFT[i][1] = -1.0 * fcRightDelayCorrAftfFFT[i][1];
	}

	// Calculate GCC for Left Direction IFFT processing
	fpLDelay_p = fftw_plan_dft_1d(FFT_PROCESSING_LEN, fcLeftDelayCorrAftfFFT, fcLeftDelayCorrBefFFT, FFTW_BACKWARD, FFTW_ESTIMATE);
	fftw_execute(fpLDelay_p);

	for (int i = 0; i < FFT_PROCESSING_LEN; i++) {
		fcLeftDelayCorrBefFFT[i][0] *= 1. / FFT_PROCESSING_LEN;
	}

	for (int i = 0; i < BLOCK_LEN; i++) {
		if (fcRightDelayCorrBefFFT[i][0] > tdoaResult->dMaxRCorrelation) {
			tdoaResult->dRightDelay = i;
			tdoaResult->dMaxRCorrelation = fcRightDelayCorrBefFFT[i][0];
		}
	}

	for (int i = 0; i < BLOCK_LEN; i++) {
		if (fcLeftDelayCorrBefFFT[i][0] > tdoaResult->dMaxLCorrelation) {
			tdoaResult->dLeftDelay = i;
			tdoaResult->dMaxLCorrelation = fcLeftDelayCorrBefFFT[i][0];
		}
	}
	//printf("tdoaResult->dMaxRCorrelation %f  tdoaResult->dMaxLCorrelation %f \n", tdoaResult->dMaxRCorrelation, tdoaResult->dMaxLCorrelation);
	printf("tdoaResult->dMaxRCorrelation %f  tdoaResult->dMaxLCorrelation %f \n", tdoaResult->dMaxRCorrelation, tdoaResult->dMaxLCorrelation);
	if (is_full(&maxCorrL)) {
		dequeue(&maxCorrL);
		dequeue(&maxCorrR);
	}
	enqueue(&maxCorrL, tdoaResult->dMaxLCorrelation);
	enqueue(&maxCorrR, tdoaResult->dMaxRCorrelation);

//	for (int i = 0; i < MAX_QUEUE_SIZE; i++) {
	if (!is_empty(&maxCorrL))
		dAccuMaxCorrL = accu_queue(&maxCorrL);
		dAccuMaxCorrR = accu_queue(&maxCorrR);
//	}

		printf("dAccuMaxCorrR %f  dAccuMaxCorrL %f \n", dAccuMaxCorrR, dAccuMaxCorrL);

	tdoaResult->dRightAngle = 180.0 * acos((tdoaResult->dRightDelay / SAMPLING_RATE) * SPEED_OF_SOUND / DISTANCE_OF_MIC) / PI;
	tdoaResult->dLeftAngle = 180.0 * acos((tdoaResult->dLeftDelay / SAMPLING_RATE) * SPEED_OF_SOUND / DISTANCE_OF_MIC) / PI;

	if (dAccuMaxCorrR >= dAccuMaxCorrL) {
	//if (tdoaResult->dMaxRCorrelation >= tdoaResult->dMaxLCorrelation) {
		printf("This is  rightSide source and estimation angle is %f \n", tdoaResult->dRightAngle);
	} else {
		printf("This is  leftSide source and estimation angle is %f \n", tdoaResult->dLeftAngle);
	}

	memcpy(fcLKeepBuf, &fcLeftBefFFT[KEEP_LEN], sizeof(fftw_complex) * KEEP_LEN);
	memcpy(fcRKeepBuf, &fcRightBefFFT[KEEP_LEN], sizeof(fftw_complex) * KEEP_LEN);

	fftw_destroy_plan(fpRight_p);
	fftw_destroy_plan(fpLeft_p);
	fftw_destroy_plan(fpRDelay_p);
	fftw_destroy_plan(fpLDelay_p);
	return;
}

