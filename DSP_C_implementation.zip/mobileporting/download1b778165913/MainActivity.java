package com.example.jongcheolboo.jeicyapp1;

import android.media.AudioRecord; // atl + enter
import android.media.MediaRecorder;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.ToggleButton;
import android.widget.Toast;
import android.view.View;
import android.media.AudioFormat;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    private AudioRecord recorder = null;
    private double SENSITIVITY = 20.0; // ������Ÿ�� ����ũ�� �Ϲ����� sensitivity�� 20 (mV/Pa)
    private double MAXIMUM_VOLTAGE = 2850.0; // mV
    private static final int SEND_THREAD_INFOMATION = 0;
    private static final int SEND_THREAD_STOP_MESSAGE = 1;
    private TextView SPLText = null;
    private CalcSPLThread mCalcSPLThread = null;
    private SendMassgeHandler mMainHandler = null;
    static int siCount = 0;
    public static final int SAMPLING_RATE = 16000;
    public static final int AUDIO_SOURCE = MediaRecorder.AudioSource.MIC;
    public static final int CHANNEL_IN_CONFIG = AudioFormat.CHANNEL_IN_MONO;
    public static final int CHANNEL_OUT_CONFIG = AudioFormat.CHANNEL_OUT_MONO;
    public static final int AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT;
    public static final int BUFFER_SIZE = AudioRecord.getMinBufferSize(SAMPLING_RATE, CHANNEL_IN_CONFIG, AUDIO_FORMAT);
    private boolean isRecording = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SPLText = (TextView)findViewById(R.id.textView2);
        final ToggleButton tb = (ToggleButton)this.findViewById(R.id.toggleButton);
        tb.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(tb.isChecked()) {

                    Toast.makeText(getApplicationContext(), "���� ����", Toast.LENGTH_SHORT).show();
                    //    mAudioPlaybackHook.start();
                    startRecording();
                } else {
                    Toast.makeText(getApplicationContext(), "���� ����", Toast.LENGTH_SHORT).show();
                    stopRecording();
                    //   mAudioPlaybackHook.stop();
                    //  File saveFile = new File(PCM_DUMP_PATH + "dump_AudioPlaybackHook_ProcessAudioBuffer.pcm");
                }
            }
        });
    }

    private void startRecording() {

        recorder = new AudioRecord(AUDIO_SOURCE, SAMPLING_RATE, CHANNEL_IN_CONFIG, AUDIO_FORMAT, BUFFER_SIZE);
        recorder.startRecording();
        //recordingThread = new Thread(new Runnable() {
        //     public void run() {
        //        readPCMData();
        //    }
        //}, "AudioRecorder Thread");
        //recordingThread.start();
        mMainHandler = new SendMassgeHandler();
        mCalcSPLThread = new CalcSPLThread();
        mCalcSPLThread.start();
    }

    private void stopRecording() {
        // stops the recording activity
        if (null != recorder) {
            recorder.stop();
            recorder.release();
            recorder = null;
            mCalcSPLThread.stopThread();
            mCalcSPLThread = null;
        }
        SPLText.setText("SPL : " + 0 + "dB");
    }
    // Thread Ŭ����
    class CalcSPLThread extends Thread implements Runnable {

        private boolean isRecording = false;
        short sData[] = new short[BUFFER_SIZE/2];
        public CalcSPLThread() {
            isRecording = true;
        }

        public void isThreadState(boolean isRecording) {
            this.isRecording = isRecording;
        }

        public void stopThread() {
            isRecording = false;
        }

        @Override
        public void run() {
            super.run();

            int value = 0;

            while (isRecording) {

                // �޽��� ������
                Message msg = mMainHandler.obtainMessage();

                // �޽��� ID ����
                msg.what = SEND_THREAD_INFOMATION;

                recorder.read(sData, 0, BUFFER_SIZE/2);
                //System.out.println("Short wirting to file" + sData.toString());
                // �޽��� ���� ���� (int ����)
                msg.arg1 = CalcSPL(sData, BUFFER_SIZE/2);

                // �޽��� ���� ����2 (int ����)
                msg.arg2 = 0;
                // �޽��� ���� ����3 (Object ����)
                String hi = new String("SPLCalc Thared �� �����ϰ� �ֽ��ϴ�.");
                msg.obj = hi;

                mMainHandler.sendMessage(msg);

                // 1�� ������
                try { Thread.sleep(1000); }
                catch (InterruptedException e) { e.printStackTrace(); }

            }

        }
    }



    private int CalcSPL(short sData[], int iFrameCount) {

        double rgdPwrSignal = 0.0, rgsdAvgSPL = 0.0;

        siCount++;

        for (int i = 0; i < iFrameCount; i++) {
            rgdPwrSignal += Math.pow((MAXIMUM_VOLTAGE / SENSITIVITY) * sData[i] / 32767.0, 2.0);
        }
        rgdPwrSignal /= iFrameCount;

        rgsdAvgSPL = 10 * Math.log10(rgdPwrSignal / (Math.pow(2.0 / 100000.0 , 2.0)));

        //System.out.printf("rgdPwrSignal %f \n", rgdPwrSignal);
        return (int)rgsdAvgSPL;

    }

    // Handler Ŭ����
    class SendMassgeHandler extends Handler {

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            switch (msg.what) {
                case SEND_THREAD_INFOMATION:
                    SPLText.setText("SoundPressureLevel = .. " + msg.arg1);
                    break;

                case SEND_THREAD_STOP_MESSAGE:
                    mCalcSPLThread.stopThread();
                    SPLText.setText("recordingThread Thread�� ���� �Ǿ����ϴ�.");
                    break;

                default:
                    break;
            }
        }

    };


}