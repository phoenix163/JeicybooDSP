/*
Parsing Wav format Header.
This program is made by jongcheol boo.

���� �̸��� �밡���� ǥ�����������.
http://jinsemin119.tistory.com/61 , https://en.wikipedia.org/wiki/Hungarian_notation , http://web.mst.edu/~cpp/common/hungarian.html

We are targetting format of 16kHz SamplingRate, mono channel, 16bit per sample.

������ǥ
1) WAV ������ header������ parsing�Ͽ� ���� ���� �ؼ�.
2) ���� ���� PCM file�� WAV HEADER������.

*/
#include<stdio.h>
#include<string.h>
#include<fftw3.h>
#include<math.h>
#include"WaveHeader.h"

#define FALSE 0
#define TRUE 1

#define BLOCK_LEN 512 // 1000*(512/16000)= 32ms.

#define DURATION 9 // 10 sec.
#define SAMPLING_RATE 16000 // 16000 sampling per 1 sec.
#define CHANNEL 1 // mono channel
#define BIT_RATE 16 // BIT PER SAMPLE 

bool OpeningFile(int argc, char** argv, FILE *fpRead, FILE *fpWrite);
void ParsingHeaderInform(WAVE_HEADER *header);
void FillingHeaderInform(WAVE_HEADER *header);

void main(int argc, char** argv) {

	// fRead�� input, fWrite�� processing���� write �� output file pointer.
	FILE *fpRead = NULL, *fpWrite =NULL;
	char rgcHeader[44] = { '\0', }; // header�� ������ �迭.
	short rgsInputBuffer[BLOCK_LEN] = { 0, };
	short rgsOutputBuffer[BLOCK_LEN] = { 0, };
	int iNumOfIteration = 0;
	WAVE_HEADER headerRead, headerWrite;

	//if (!OpeningFile(argc, argv, fpRead, fpWrite))
	//	return;

	if (argc != 3) {
		printf("path�� 2�� �Է��ؾ� �մϴ�.\n"); // input path, output path
		return;
	}
	else {
		for (int i = 1; i < 3; i++)
			printf("%d-th path %s \n", i, argv[i]);
	}
	printf("1-th path %s\n", argv[1]);
	if ((fpRead = fopen(argv[1], "rb")) == NULL) {
		printf("Read File Open Error\n");
		return;
	}
	printf("2-th path %s\n", argv[2]);
	if ((fpWrite = fopen(argv[2], "wb")) == NULL) {
		printf("Write File Open Error\n");
		return;
	}

	fread(&headerRead, sizeof(headerRead), 1, fpRead);
	ParsingHeaderInform(&headerRead);

	FillingHeaderInform(&headerWrite);
	fwrite(&headerWrite, sizeof(headerWrite), 1, fpWrite);
	


	while (true)
	{
		if ((fread(rgsInputBuffer, sizeof(short), BLOCK_LEN, fpRead)) == 0) {
			printf("Break! The buffer is insufficient.\n");
			break;
		}
		printf(" input[0] %d, input[1] %d, input[2] %d \n", rgsInputBuffer[0], rgsInputBuffer[1], rgsInputBuffer[2]);
		//getchar();
		fwrite(rgsInputBuffer, sizeof(short), BLOCK_LEN, fpWrite);
	}
	printf("Processing End\n");
	fclose(fpRead);
	fclose(fpWrite);
	getchar();
	return;
}

bool OpeningFile(int argc, char** argv, FILE *fpRead, FILE *fpWrite) {

	if (argc != 3) {
		printf("path�� 2�� �Է��ؾ� �մϴ�.\n"); // input path, output path
		return FALSE;
	}
	else {
		for (int i = 1; i < 3; i++)
			printf("%d-th path %s \n", i, argv[i]);
	}
	printf("1-th path %s\n", argv[1]);
	if ((fpRead = fopen(argv[1], "rb")) == NULL) {
		printf("Read File Open Error\n");
		return FALSE;
	}
	printf("2-th path %s\n", argv[2]);
	if ((fpWrite = fopen(argv[2], "wb")) == NULL) {
		printf("Write File Open Error\n");
		return FALSE;
	}
	return TRUE;
}


void ParsingHeaderInform(WAVE_HEADER *header) {

	// "RIFF"
	printf("RIFF chunkID   %s \n", header->Riff.ChunkID);
	printf("RIFF chunkSize %u \n", header->Riff.ChunkSize);
	printf("RIFF format    %s \n", header->Riff.Format);

	// "FMT"
	printf("header->Fmt.ChunkId =     %s\n", header->Fmt.ChunkID);
	printf("header->Fmt.ChunkSize =   %u\n", header->Fmt.ChunkSize);
	printf("header->Fmt.AudioFormat = %hd\n", header->Fmt.AudioFormat);
	printf("header->Fmt.NumChannels = %hd\n", header->Fmt.NumChannels);
	printf("header->Fmt.SampleRate =  %u\n", header->Fmt.SampleRate);
	printf("header->Fmt.AvgByteRate = %u\n", header->Fmt.AvgByteRate);
	printf("header->Fmt.BlockAlign =  %hd\n", header->Fmt.BlockAlign);
	printf("header->Fmt.BitPerSample =%hd\n", header->Fmt.BitPerSample);

	// "DATA"
	printf("header->Data.ChunkID    %s\n", header->Data.ChunkID);
	printf("header->Data.ChunkSize  %u\n", header->Data.ChunkSize);

}

void FillingHeaderInform(WAVE_HEADER *header) {

	// "RIFF"
	memcpy(header->Riff.ChunkID, "RIFF", sizeof(char) * 4);
	header->Riff.ChunkSize = DURATION * SAMPLING_RATE * CHANNEL * BIT_RATE / 8 + 36; // CHUNK_ID�� CHUNK_SIZE �� 8BYTE�� ������ ��ü ũ��.
	memcpy(header->Riff.Format, "WAVE", sizeof(char) * 4);

	// "FMT"
	memcpy(header->Fmt.ChunkID, "fmt ", 4);
	header->Fmt.ChunkSize = 0x10; // FMT���� CHUNK�� ������(8BYte�� ������) FMT�� SIZE
	header->Fmt.AudioFormat = WAVE_FORMAT_PCM; // 2 Byte
	header->Fmt.NumChannels = CHANNEL; // 2 Byte
	header->Fmt.SampleRate = SAMPLING_RATE;
	header->Fmt.AvgByteRate = SAMPLING_RATE * CHANNEL * BIT_RATE / 8;
	header->Fmt.BlockAlign = CHANNEL * BIT_RATE / 8; // 2 Byte
	header->Fmt.BitPerSample = BIT_RATE; // 2 Byte

	// "DATA"
	memcpy(header->Data.ChunkID, "data", 4);
	header->Data.ChunkSize = DURATION * SAMPLING_RATE * CHANNEL * BIT_RATE / 8;

}