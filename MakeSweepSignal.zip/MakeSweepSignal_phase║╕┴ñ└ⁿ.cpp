/*
Make SweepSignal
This program is made by jongcheol boo.

���� �̸��� �밡���� ǥ�����������.
http://jinsemin119.tistory.com/61 , https://en.wikipedia.org/wiki/Hungarian_notation , http://web.mst.edu/~cpp/common/hungarian.html
We are targetting format of 16kHz SamplingRate, mono channel, 16bit per sample.
SweepSignal�� ����, Filter�� input signal�� Ȱ���Ͽ� �ؼ��Ѵ�.
�ֱ��� ������ ���ļ���.
https://en.wikipedia.org/wiki/Sine_wave

*/
#include<stdio.h>
#include<string.h>
#include<math.h>

#define PI 3.141592
#define BLOCK_SIZE 1024 // 1000*(1024/16000)= 64ms.
#define DEFAULT_SAMPLINGRATE 16000.0
#define MAX_SWEEP_SAMPLINGRATE 8000.0
#define NUM_OF_PROCESSING 100
#define AMPLITUDE 1000.0

void MakeSweepSignal(short *psOutputBuffer, int iFrameCount, int iNumOfProcessing);

void main(int argc, char** argv) {

	// fRead�� input, fWrite�� processing���� write �� output file pointer.
	FILE *fpRead;
	FILE *fpWrite;
	char rgcHeader[44] = { '\0', }; // header�� ������ �迭.
	short rgsOutputBuffer[BLOCK_SIZE * NUM_OF_PROCESSING] = { 0, };
	int iNumOfProcessing = NUM_OF_PROCESSING;

	if (argc != 3) {
		printf("path�� 2�� �Է��ؾ� �մϴ�.\n"); // input path, output path
		return;
	}
	else {
		for (int i = 1; i < 3; i++)
			printf("%d-th path %s \n", i, argv[i]);
	}

	if ((fpRead = fopen(argv[1], "rb")) == NULL)
		printf("Read File Open Error\n");

	if ((fpWrite = fopen(argv[2], "wb")) == NULL)
		printf("Write File Open Error\n");

	// Read�� Wav ���� �� ���� Header 44Byte ��ŭ Write�� Wav���Ͽ� write.
	fread(rgcHeader, 1, 44, fpRead);
	//fwrite(rgcHeader, 1, 44, fpWrite);

	MakeSweepSignal(rgsOutputBuffer, BLOCK_SIZE, iNumOfProcessing);
	fwrite(rgsOutputBuffer, sizeof(short), BLOCK_SIZE * iNumOfProcessing, fpWrite);
	printf("Total %f sec. \n", iNumOfProcessing * BLOCK_SIZE / DEFAULT_SAMPLINGRATE);

	printf("Processing End\n");
	fclose(fpRead);
	fclose(fpWrite);
	getchar();
	return;
}

void MakeSweepSignal(short *psOutputBuffer, int iFrameCount, int iNumOfProcessing) {

	double dTotalIteration = iFrameCount * iNumOfProcessing;
	double dFrequency = 0.0;
	double dUnitTime = 1 / DEFAULT_SAMPLINGRATE;
	double dTemp = 0.0;

	for (int i = 0; i < dTotalIteration; i++) {
		dFrequency = (MAX_SWEEP_SAMPLINGRATE * i / 2.0) / (dTotalIteration - 1); // gradually increase up to 8kHz
		//printf(" frequency %f \n", dFrequency);
		dTemp = 2 * PI * dFrequency * i * dUnitTime; // 2 * PI * f * k * T
		psOutputBuffer[i] = AMPLITUDE * sin(dTemp);
	}
	return;
}