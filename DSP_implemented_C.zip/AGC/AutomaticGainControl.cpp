/*
Automatic gain Control
This program is made by jongcheol boo.

���� �̸��� �밡���� ǥ�����������.
http://jinsemin119.tistory.com/61 , https://en.wikipedia.org/wiki/Hungarian_notation , http://web.mst.edu/~cpp/common/hungarian.html

We are targetting format of 48kHz SamplingRate, mono channel, 16bit per sample.

FFT ��ȯ�� ���� Frequency Domain �ؼ�
https://ko.wikipedia.org/wiki/%EA%B3%A0%EC%86%8D_%ED%91%B8%EB%A6%AC%EC%97%90_%EB%B3%80%ED%99%98

AGC�� �ϴµ�, Subband��� ������, �뿪���� ������ Gain�� �����ϵ��� �Ͽ���.
2 octave ,Q factor = 0.667
http://www.sengpielaudio.com/calculator-cutoffFrequencies.htm
���� f1, f2���.
Fc      F1(lower)  F2(upper)
100		50         200
2000	1000	   3999
10000	5001	   19994

*/

#include<stdio.h>
#include<string.h>
#include<math.h>
#include<fftw3.h>

#define FALSE 0
#define TRUE 1
#define PI 3.141592
#define NUM_OF_BANDS 3
#define BLOCK_LEN 512 // 1000*(512/16000)= 32ms.
#define FFT_PROCESSING_LEN 1024// 2�� n�°��� �Ǿ�� �Ѵ�.
#define FILTER_LENGTH 64
#define THRESHOLD_OF_ENERGY 300.0
#define THRESHOLD_OF_ZCR 50
#define SAMPLING_RATE 16000.0
#define TARGET_AVGENERGY 100.0
#define MIN_GAIN 0.3
#define MAX_GAIN 1.3
#define MIN(X,Y) ((X) < (Y) ? (X) : (Y))  
#define MAX(X,Y) ((X) > (Y) ? (X) : (Y)) 
#define ATTACK_TIME 0.005//5 ms
#define RELEASE_TIME 0.02// 20 ms
#define ATTACK_LEN (ATTACK_TIME *SAMPLING_RATE)
#define RELEASE_LEN (RELEASE_TIME *SAMPLING_RATE)

double rgdFirLPF_coefficients[NUM_OF_BANDS][FILTER_LENGTH] = {
	{ 0.00214452, 0.00222087, 0.00242119, 0.00274595, 0.00319419, 0.00376353
	, 0.00445017, 0.00524896, 0.00615339, 0.00715568, 0.00824689, 0.00941694
	, 0.01065478, 0.01194848, 0.01328538, 0.0146522, 0.0160352, 0.01742037
	, 0.01879351, 0.02014049, 0.02144732, 0.02270036, 0.02388649, 0.0249932
	, 0.0260088, 0.02692251, 0.02772464, 0.02840662, 0.02896117, 0.02938237
	, 0.0296657, 0.02980813, 0.02980813, 0.0296657, 0.02938237, 0.02896117
	, 0.02840662, 0.02772464, 0.02692251, 0.0260088, 0.0249932, 0.02388649
	, 0.02270036, 0.02144732, 0.02014049, 0.01879351, 0.01742037, 0.0160352
	, 0.0146522, 0.01328538, 0.01194848, 0.01065478, 0.00941694, 0.00824689
	, 0.00715568, 0.00615339, 0.00524896, 0.00445017, 0.00376353, 0.00319419
	, 0.00274595, 0.00242119, 0.00222087, 0.00214452 },

	{ 0.12367327, -0.10276262, -0.02234269, 0.03167003, 0.0547729, 0.05140893
	, 0.03081814, 0.00299591, -0.02366987, -0.04349268, -0.05376137, -0.05452579
	, -0.04745596, -0.03553497, -0.02217869, -0.01068084, -0.00386258, -0.00354693
	, -0.0103768, -0.02344048, -0.04031911, -0.05751209, -0.07082901, -0.07669666
	, -0.07179928, -0.05545299, -0.02781796, 0.00719919, 0.04523218, 0.08098895
	, 0.10846503, 0.12330209, 0.12330209, 0.10846503, 0.08098895, 0.04523218
	, 0.00719919, -0.02781796, -0.05545299, -0.07179928, -0.07669666, -0.07082901
	, -0.05751209, -0.04031911, -0.02344048, -0.0103768, -0.00354693, -0.00386258
	, -0.01068084, -0.02217869, -0.03553497, -0.04745596, -0.05452579, -0.05376137
	, -0.04349268, -0.02366987, 0.00299591, 0.03081814, 0.05140893, 0.0547729
	, 0.03167003, -0.02234269, -0.10276262, 0.12367327 },

	{ -7.55158422e-04, -8.19652875e-04, -5.52165156e-04, 5.27676754e-05
	, 8.71692087e-04, 1.59761859e-03, 1.79027894e-03, 1.07089152e-03
	, -6.00182029e-04, -2.71993435e-03, -4.28903449e-03, -4.18814756e-03
	, -1.78274675e-03, 2.52294683e-03, 7.12592773e-03, 9.68175358e-03
	, 8.12139010e-03, 1.84461628e-03, -7.49363837e-03, -1.61283205e-02
	, -1.94407498e-02, -1.39957949e-02, 4.24923872e-04, 1.97426806e-02
	, 3.61502759e-02, 4.04103443e-02, 2.52182025e-02, -1.15912140e-02
	, -6.53085049e-02, -1.24950504e-01, -1.76205185e-01, -2.05805378e-01
	, 7.94194622e-01, -1.76205185e-01, -1.24950504e-01, -6.53085049e-02
	, -1.15912140e-02, 2.52182025e-02, 4.04103443e-02, 3.61502759e-02
	, 1.97426806e-02, 4.24923872e-04, -1.39957949e-02, -1.94407498e-02
	, -1.61283205e-02, -7.49363837e-03, 1.84461628e-03, 8.12139010e-03
	, 9.68175358e-03, 7.12592773e-03, 2.52294683e-03, -1.78274675e-03
	, -4.18814756e-03, -4.28903449e-03, -2.71993435e-03, -6.00182029e-04
	, 1.07089152e-03, 1.79027894e-03, 1.59761859e-03, 8.71692087e-04
	, 5.27676754e-05, -5.52165156e-04, -8.19652875e-04, -7.55158422e-04 }
};
bool VoiceActivityDetection(short *rgsInputBuffer, int iFrameCount);
void SplitBand(short *psInputBuffer, short *psOutputBuffer, int iFrameCount, bool bVAD);
double CalculateGain(double rgdTempBand1[FFT_PROCESSING_LEN][2], double dAgcGainBand, bool bVAD);

void main(int argc, char** argv) {

	// fRead�� input, fWrite�� processing���� write �� output file pointer.
	FILE *fpRead;
	FILE *fpWrite;
	char rgcHeader[44] = { '\0', }; // header�� ������ �迭.
	short rgsInputBuffer[BLOCK_LEN] = { 0, };
	short rgsOutputBuffer[BLOCK_LEN] = { 0, };
	bool bVAD = FALSE;

	if (argc != 3) {
		printf("path�� 2�� �Է��ؾ� �մϴ�.\n"); // input path, output path
		return;
	}
	else {
		for (int i = 1; i < 3; i++)
			printf("%d-th path %s \n", i, argv[i]);
	}

	if ((fpRead = fopen(argv[1], "rb")) == NULL)
		printf("Read File Open Error\n");

	if ((fpWrite = fopen(argv[2], "wb")) == NULL)
		printf("Write File Open Error\n");

	// Read�� Wav ���� �� ���� Header 44Byte ��ŭ Write�� Wav���Ͽ� write.
	fread(rgcHeader, 1, 44, fpRead);
	//fwrite(rgcHeader, 1, 44, fpWrite);

	while (true)
	{
		if ((fread(rgsInputBuffer, sizeof(short), BLOCK_LEN, fpRead)) == 0) {
			printf("Break! The buffer is insufficient.\n");
			break;
		}
		bVAD = VoiceActivityDetection(rgsInputBuffer, BLOCK_LEN);
		SplitBand(rgsInputBuffer, rgsOutputBuffer, BLOCK_LEN, bVAD);
		fwrite(rgsOutputBuffer, sizeof(short), BLOCK_LEN, fpWrite);
	}
	printf("Processing End\n");
	fclose(fpRead);
	fclose(fpWrite);
	getchar();
	return;
}

void SplitBand(short *psInputBuffer, short *psOutputBuffer, int iFrameCount, bool bVAD) {

	fftw_complex fcInputBefFFT[FFT_PROCESSING_LEN] = { 0, }, fcInputAftFFT[FFT_PROCESSING_LEN] = { 0, };
	fftw_complex fcFilter1BefFFT[FFT_PROCESSING_LEN] = { 0, }, fcFilter1AftFFT[FFT_PROCESSING_LEN] = { 0, };
	fftw_complex fcFilter2BefFFT[FFT_PROCESSING_LEN] = { 0, }, fcFilter2AftFFT[FFT_PROCESSING_LEN] = { 0, };
	fftw_complex fcFilter3BefFFT[FFT_PROCESSING_LEN] = { 0, }, fcFilter3AftFFT[FFT_PROCESSING_LEN] = { 0, };
	fftw_complex fcOutputBefFFT[FFT_PROCESSING_LEN] = { 0, }, fcOutputAftFFT[FFT_PROCESSING_LEN] = { 0, };
	fftw_plan fpInput_p, fpFilter1_p, fpFilter2_p, fpFilter3_p, fpOutput_p;
	static short rgssKeepBuffer[FILTER_LENGTH - 1] = { 0, };
	double rgdTempBand1[FFT_PROCESSING_LEN][2] = { 0, }, rgdTempBand2[FFT_PROCESSING_LEN][2] = { 0, }, rgdTempBand3[FFT_PROCESSING_LEN][2] = { 0, };
	static double dAgcGainBand1 = 1.0, dAgcGainBand2 = 1.0, dAgcGainBand3 = 1.0;

	for (int i = 0; i < FILTER_LENGTH - 1; i++) {
		fcInputBefFFT[i][0] = rgssKeepBuffer[i];
	}
	for (int i = 0; i < iFrameCount; i++) {
		fcInputBefFFT[FILTER_LENGTH - 1 + i][0] = psInputBuffer[i];
	}
	for (int i = 0; i < FILTER_LENGTH; i++) {
		fcFilter1BefFFT[i][0] = rgdFirLPF_coefficients[0][i];
		fcFilter2BefFFT[i][0] = rgdFirLPF_coefficients[1][i];
		fcFilter3BefFFT[i][0] = rgdFirLPF_coefficients[2][i];
	}
	fpInput_p = fftw_plan_dft_1d(FFT_PROCESSING_LEN, fcInputBefFFT, fcInputAftFFT, FFTW_FORWARD, FFTW_ESTIMATE);
	fpFilter1_p = fftw_plan_dft_1d(FFT_PROCESSING_LEN, fcFilter1BefFFT, fcFilter1AftFFT, FFTW_FORWARD, FFTW_ESTIMATE);
	fpFilter2_p = fftw_plan_dft_1d(FFT_PROCESSING_LEN, fcFilter2BefFFT, fcFilter2AftFFT, FFTW_FORWARD, FFTW_ESTIMATE);
	fpFilter3_p = fftw_plan_dft_1d(FFT_PROCESSING_LEN, fcFilter3BefFFT, fcFilter3AftFFT, FFTW_FORWARD, FFTW_ESTIMATE);
	fpOutput_p = fftw_plan_dft_1d(FFT_PROCESSING_LEN, fcOutputAftFFT, fcOutputBefFFT, FFTW_BACKWARD, FFTW_ESTIMATE);
	fftw_execute(fpInput_p);
	fftw_execute(fpFilter1_p);
	fftw_execute(fpFilter2_p);
	fftw_execute(fpFilter3_p);
	for (int i = 0; i < FFT_PROCESSING_LEN; i++) {
		rgdTempBand1[i][0] = (fcInputAftFFT[i][0] * fcFilter1AftFFT[i][0] - fcInputAftFFT[i][1] * fcFilter1AftFFT[i][1]) * dAgcGainBand1;
		rgdTempBand1[i][1] = (fcInputAftFFT[i][0] * fcFilter1AftFFT[i][1] + fcInputAftFFT[i][1] * fcFilter1AftFFT[i][0]) * dAgcGainBand1;

		rgdTempBand2[i][0] = (fcInputAftFFT[i][0] * fcFilter2AftFFT[i][0] - fcInputAftFFT[i][1] * fcFilter2AftFFT[i][1]) * dAgcGainBand2;
		rgdTempBand2[i][1] = (fcInputAftFFT[i][0] * fcFilter2AftFFT[i][1] + fcInputAftFFT[i][1] * fcFilter2AftFFT[i][0]) * dAgcGainBand2;

		rgdTempBand3[i][0] = (fcInputAftFFT[i][0] * fcFilter3AftFFT[i][0] - fcInputAftFFT[i][1] * fcFilter3AftFFT[i][1]) * dAgcGainBand3;
		rgdTempBand3[i][1] = (fcInputAftFFT[i][0] * fcFilter3AftFFT[i][1] + fcInputAftFFT[i][1] * fcFilter3AftFFT[i][0]) * dAgcGainBand3;

		fcOutputAftFFT[i][0] = rgdTempBand1[i][0] +rgdTempBand2[i][0] + rgdTempBand3[i][0];
		fcOutputAftFFT[i][1] = rgdTempBand1[i][1] +rgdTempBand2[i][1] + rgdTempBand3[i][1];
	}


	dAgcGainBand1 = CalculateGain(rgdTempBand1, dAgcGainBand1, bVAD);
	dAgcGainBand2 = CalculateGain(rgdTempBand2, dAgcGainBand2, bVAD);
	dAgcGainBand3 = CalculateGain(rgdTempBand3, dAgcGainBand3, bVAD);

	fftw_execute(fpOutput_p);
	for (int i = 0; i < iFrameCount; i++) {
		psOutputBuffer[i] = fcOutputBefFFT[i + FILTER_LENGTH - 1][0] * 1. / FFT_PROCESSING_LEN;
	}
	// ������ �� ������ �κ��� FILTER_LENGTH -1 ��ŭ Keep��. 
	memcpy(rgssKeepBuffer, &psInputBuffer[iFrameCount - FILTER_LENGTH + 1], sizeof(rgssKeepBuffer));
	fftw_destroy_plan(fpInput_p);
	fftw_destroy_plan(fpFilter1_p);
	fftw_destroy_plan(fpFilter2_p);
	fftw_destroy_plan(fpFilter3_p);
	fftw_destroy_plan(fpOutput_p);
	return;
}

bool VoiceActivityDetection(short *rgsInputBuffer, int iFrameCount) {

	static short rgssKeepBuffer[BLOCK_LEN] = { 0, };
	short rgsProcessingBuffer[FFT_PROCESSING_LEN] = { 0, };
	double dEnergy = 0.0;
	int dZCR = 0;
	memcpy(rgsProcessingBuffer, rgssKeepBuffer, sizeof(rgssKeepBuffer));
	memcpy(rgsProcessingBuffer + BLOCK_LEN, rgsInputBuffer, sizeof(short) * iFrameCount);

	for (int i = 0; i < FFT_PROCESSING_LEN; i++) {
		rgsProcessingBuffer[i] *= (0.54 - 0.46 * cos(2 * PI * i / (FFT_PROCESSING_LEN - 1))); // Windowing 
		// ���� ���� �� �κ�, short�� �Ǿ, �Ҽ��� ©��.

		//Calc Energy
		dEnergy += pow(rgsProcessingBuffer[i], 2.0);

		//Calc Zero Crossing Rate
		if (i != FFT_PROCESSING_LEN) {
			if (rgsProcessingBuffer[i] * rgsProcessingBuffer[i + 1] < 0)
				dZCR++;
		}
	}
	dEnergy /= FFT_PROCESSING_LEN;
	//dZCR /= (FFT_PROCESSING_SIZE - 1);

	printf(" dEnergy %f , dZCR %d \n", dEnergy, dZCR);
	if (dEnergy > THRESHOLD_OF_ENERGY || dZCR < THRESHOLD_OF_ZCR) {
		return TRUE;
	}
	else {
		return FALSE;
	}

	memcpy(rgssKeepBuffer, &rgsInputBuffer[iFrameCount - BLOCK_LEN], sizeof(rgssKeepBuffer));

}

double CalculateGain(double rgdTempBand1[FFT_PROCESSING_LEN][2], double dAgcGainBand, bool bVAD) {

	double dNextGain = 0.0, dAvgInEnergy = 0.0;

	for (int i = 0; i < FFT_PROCESSING_LEN; i++) {

		dAvgInEnergy = pow(rgdTempBand1[i][0], 2.0) + pow(rgdTempBand1[i][1], 2.0) / (double)FFT_PROCESSING_LEN;
	}

	if (dAvgInEnergy > TARGET_AVGENERGY) {

		dNextGain = (1.0 - (1.0 / ATTACK_LEN)) * dAgcGainBand + (1.0 / ATTACK_LEN) * MIN_GAIN;

	} else if (bVAD == TRUE && dAvgInEnergy <= TARGET_AVGENERGY) {
		dNextGain = (1.0 - (1.0 / RELEASE_LEN)) * dAgcGainBand + (1.0 / RELEASE_LEN) * MAX_GAIN;
	}
	else {
		dNextGain = (1.0 - (1.0 / ATTACK_LEN)) * dAgcGainBand + (1.0 / ATTACK_LEN) * 1.0;
	}

	dNextGain = MIN(MAX_GAIN, dNextGain);
	dNextGain = MAX(MIN_GAIN, dNextGain);

	return dNextGain;
}