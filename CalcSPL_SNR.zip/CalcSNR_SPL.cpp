/*
VAD��� �������� ���� �� SNR(Signal to Noise Ratio) , SPL(Sound Pressure Level) ���ϱ�.
This program is made by jongcheol boo.

���� �̸��� �밡���� ǥ�����������.
http://jinsemin119.tistory.com/61 , https://en.wikipedia.org/wiki/Hungarian_notation , http://web.mst.edu/~cpp/common/hungarian.html

We are targetting format of 16kHz SamplingRate, mono channel, 16bit per sample.

refer to http://www.engineeringtoolbox.com/sound-pressure-d_711.html
http://www.ni.com/white-paper/14349/en/

*/
#include<stdio.h>
#include<string.h>
#include<fftw3.h>
#include<math.h>


#define SENSITIVITY 10.0 // (mV/Pa)
#define MAXIMUM_VOLTAGE 12000 // mV
#define THRESHOLD_OF_ENERGY 1500.0
#define THRESHOLD_OF_ZCR 0
#define FALSE 0
#define TRUE 1
#define PI 3.141592
#define KEEP_LEN 512
#define BLOCK_LEN 512 // 1000*(512/16000)= 32ms.
#define FFT_PROCESSING_SIZE 1024// 2�� n�°��� �Ǿ�� �Ѵ�.
#define NOISE_ESTIMATION_FRAMECOUNT 10.0
#define SIGNAL_FLAG 1
#define NOISE_FLAG 0
#define ERROR -1

bool VoiceActivityDetection(short *rgsInputBuffer, int iFrameCount);
double CalcAvgPowerOf(short *rgsInputBuffer, int iFrameCount, int iFlag);
double CalcAvgSPL(short *rgsInputBuffer, int iFrameCount);

void main(int argc, char** argv) {

	// fRead�� input, fWrite�� processing���� write �� output file pointer.
	FILE *fpRead;
	char rgcHeader[44] = { '\0', }; // header�� ������ �迭.
	short rgsInputBuffer[BLOCK_LEN] = { 0, };
	int iNumOfIteration = 0;
	double dPowerOfSignal = 0.0, dPowerOfNoise = 0.0, dSNR = 0.0, dSPL = 0.0;
	if (argc != 2) {
		printf("path�� 1�� �Է��ؾ� �մϴ�.\n"); // input path, output path
		return;
	}
	else {
		for (int i = 1; i < 2; i++)
			printf("%d-th path %s \n", i, argv[i]);
	}

	if ((fpRead = fopen(argv[1], "rb")) == NULL)
		printf("Read File Open Error\n");

	// Read�� Wav ���� �� ���� Header 44Byte ��ŭ Write�� Wav���Ͽ� write.
	fread(rgcHeader, 1, 44, fpRead);
	//fwrite(rgcHeader, 1, 44, fpWrite);

	while (true)
	{
		if ((fread(rgsInputBuffer, sizeof(short), BLOCK_LEN, fpRead)) == 0) {
			printf("Break! The buffer is insufficient.\n");
			break;
		}
		iNumOfIteration++;
		if (VoiceActivityDetection(rgsInputBuffer, BLOCK_LEN)) {
			dPowerOfSignal = CalcAvgPowerOf(rgsInputBuffer, BLOCK_LEN, SIGNAL_FLAG);
		}
		else {
			dPowerOfNoise = CalcAvgPowerOf(rgsInputBuffer, BLOCK_LEN, NOISE_FLAG);
		}
		dSPL = CalcAvgSPL(rgsInputBuffer, BLOCK_LEN);
	}

	dSNR = 10 * log10(dPowerOfSignal / dPowerOfNoise);

	printf("SNR %f, SPR %f \n", dSNR, dSPL);
	printf("Processing End\n");
	fclose(fpRead);
	getchar();
	return;
}

bool VoiceActivityDetection(short *rgsInputBuffer, int iFrameCount) {

	static short rgssKeepBuffer[KEEP_LEN] = { 0, };
	short rgsProcessingBuffer[FFT_PROCESSING_SIZE] = { 0, };
	double dEnergy = 0.0;
	int dZCR = 0;
	memcpy(rgsProcessingBuffer, rgssKeepBuffer, sizeof(rgssKeepBuffer));
	memcpy(rgsProcessingBuffer + KEEP_LEN, rgsInputBuffer, sizeof(short) * iFrameCount);

	for (int i = 0; i < FFT_PROCESSING_SIZE; i++) {
		rgsProcessingBuffer[i] *= (0.54 - 0.46 * cos(2 * PI * i / (FFT_PROCESSING_SIZE - 1))); // Windowing 
		// ���� ���� �� �κ�, short�� �Ǿ, �Ҽ��� ©��.

		//Calc Energy
		dEnergy += pow(rgsProcessingBuffer[i], 2.0);

		//Calc Zero Crossing Rate
		if (i != FFT_PROCESSING_SIZE) {
			if (rgsProcessingBuffer[i] * rgsProcessingBuffer[i + 1] < 0)
				dZCR++;
		}
	}
	dEnergy /= FFT_PROCESSING_SIZE;

	//printf(" dEnergy %f , dZCR %d \n", dEnergy, dZCR);
	if (dEnergy > THRESHOLD_OF_ENERGY || dZCR < THRESHOLD_OF_ZCR) {
		return TRUE;
	}
	else {
		return FALSE;
	}

	memcpy(rgssKeepBuffer, &rgsInputBuffer[iFrameCount - KEEP_LEN], sizeof(rgssKeepBuffer));
}

double CalcAvgPowerOf(short *rgsInputBuffer, int iFrameCount, int iFlag) {
	static double rgsdAvgSignal = 0.0, rgsdAvgNoise = 0.0;
	static int siSIGCount = 0, siNSCount = 0;
	double rgdPwrSignal = 0.0, rgdPwrNoise = 0.0;
	if (SIGNAL_FLAG == iFlag) {
		siSIGCount++;
		for (int i = 0; i < iFrameCount; i++) {
			rgdPwrSignal += pow(rgsInputBuffer[i], 2.0);
		}

		rgdPwrSignal /= iFrameCount;
		rgsdAvgSignal += rgdPwrSignal;
		if (siSIGCount > 1)
			rgsdAvgSignal /= 2.0;

		return rgsdAvgSignal;
	}
	else if (NOISE_FLAG == iFlag) {
		siNSCount++;
		for (int i = 0; i < iFrameCount; i++) {
			rgdPwrNoise += pow(rgsInputBuffer[i], 2.0);
		}

		rgdPwrNoise /= iFrameCount;
		rgsdAvgNoise += rgdPwrNoise;
		if (siSIGCount > 1)
			rgsdAvgNoise /= 2.0;

		return rgsdAvgNoise;
	}
	else {
		return ERROR;
	}
}
double CalcAvgSPL(short *rgsInputBuffer, int iFrameCount) {
	double rgdPwrSignal = 0.0, rgsdAvgSPL = 0.0;
	static int siCount = 0;
	siCount++;

	for (int i = 0; i < iFrameCount; i++) {
		rgdPwrSignal += pow((MAXIMUM_VOLTAGE / SENSITIVITY) * rgsInputBuffer[i] / 32767.0, 2.0);
	}
	rgdPwrSignal /= iFrameCount;

	rgsdAvgSPL += 10 * log10(rgdPwrSignal / (pow(2.0 / 100000.0 , 2.0)));

	if (siCount > 1)
		rgdPwrSignal /= 2.0;

	return rgdPwrSignal;
}